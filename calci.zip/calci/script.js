let currentInput = '';
let operator = '';
let display = document.getElementById('display');

function appendNumber(number) {
    currentInput += number;
    updateDisplay();
}

function setOperator(op) {
    operator = op;
    currentInput += ' ' + operator + ' ';
    updateDisplay();
}

function calculate() {
    try {
        currentInput = eval(currentInput).toString();
        updateDisplay();
    } catch (error) {
        display.innerHTML = 'Error';
    }
}

function clearDisplay() {
    currentInput = '';
    operator = '';
    updateDisplay();
}

function updateDisplay() {
    display.innerHTML = currentInput;
}
